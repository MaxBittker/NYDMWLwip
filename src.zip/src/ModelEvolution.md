﻿<div class="main">
        <section>
            <div class="container">




<br>
# RENEW It *Now* NY: A 21st Century Solution


<img src="assets/Evolution of Design-Build Contracting.png" class="img-responsive center-block" alt="Evolution of Design-Build Contracting" style="min-width: 70%;"> 


<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>

