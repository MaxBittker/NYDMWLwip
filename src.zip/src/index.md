<div class="full_page_photo" style="background-image: url(assets/hero.jpg);">
     <div class="container">
          <section class="call_to_action">
               <h3 class="animated fadeInDown skincolored"><i>Just possibly the coolest public-private innovation in the State of New York </i>
</h3>
               <br>
               <h4 class="animated fadeInUp"><i> since the construction of the Erie Canal!</i></h4>
          </section>
     </div>
</div>

<div class="main">
        <section>
            <div class="container">

<div class="text-center heroText">

<img src="assets/RENEW NYGB Logo.PNG" style="margin: 10px; max-width:900px; ">
<h3> <i>Energizing the marketplace to promote rapid adoption of energy efficient
technologies in order to drive reductions in greenhouse gas emissions </i></h3>
<br>

<ul style="margin:auto; max-width:700px;">
<li style="text-align:left;"> A turnkey funding and implementation package that enables customers to
    do more projects *and do them now*, without using their own capital

<li style="text-align:left;"> A strategic approach that empowers customers to take immediate action
    while preserving capital and creating net positive cash flows from day one
</ul>
</div>
<br>

<div class="row">
<div class="col-sm-6">
    <h2 class="text-center blackoverride"> <b>E-Firms</b> </h2>
    <a href="EnergyServiceProviders.html" class="text-center"><h3> *Learn More* </h3></a>

<h4>A NY Green Bank-supported platform that helps restructure
 industry boundaries to the benefit of all participants. Better
 serve and grow the marketplace with an innovative, turnkey
 energy-efficiency-as-a-service contracting model (EEaaS&trade;). </h4>

</div>

<div class="col-sm-1"></div>
<div class="col-sm-5">
    <h2 class="text-center blackoverride"> <b>Building Owners </b> </h2>
    <a href="BuildingOwnersandManagers.html" class="text-center"><h3> *Learn More* </h3></a>
<h4> Better understand, *trust*, and successfully leverage
 an innovative funding mechanism/deal structure to generate
 net positive cash flow from day one of a building upgrade
 or energy infrastructure project.</h4>

</div>
</div>
