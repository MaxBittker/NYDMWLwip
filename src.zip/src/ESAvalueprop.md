<div class="main">
        <section>
            <div class="container">


<!-- # RENEW It *Now* NY ESA: The Value Proposition -->

<img src="assets/RENEW ESA Benefits Value Prop.png" class="img-responsive center-block" alt="ESA: The Value Proposition"> 

<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>