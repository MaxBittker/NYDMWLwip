<div class="main">
        <section>
            <div class="container">


<!-- # RENEW It *Now* NY� ESA Benefits: The Value Proposition -->
<br>


<img src="assets/NYDMwL ESA Benefits Value Prop.png" class="img-responsive center-block" alt="RENEW It *Now* NY Benefits Proposition" style="min-width:70%"> 

<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>