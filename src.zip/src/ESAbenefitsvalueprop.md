<div class="main">
        <section>
            <div class="container">


<!-- # NY Doing More with Less(TM) ESA Benefits: The Value Proposition -->
<br>


<img src="assets/NYDMwL ESA Benefits Value Prop.png" class="img-responsive center-block" alt="NYDMwL benefits proposition" style="min-width:70%"> 

<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>