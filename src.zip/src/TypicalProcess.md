<div class="main">
        <section>
            <div class="container">


<!-- # NY Doing More with Less(TM) Typical Process -->
<br>
<br>

<img src="assets/NYDMwL ESA Typical Process.png" class="img-responsive center-block" alt="NYDMwL ESA Typical Process"> 


<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>
