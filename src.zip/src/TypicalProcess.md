<div class="main">
        <section>
            <div class="container">


<!-- # RENEW It *Now* NY Typical Process -->
<br>
<br>

<img src="assets/Typical Process Diagram.png" class="img-responsive center-block" alt="Typical Process Diagram"> 


<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>
