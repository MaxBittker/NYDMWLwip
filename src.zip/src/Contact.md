<div class="full_page_photo" style="background-image: url(assets/hero.jpg);">
     <div class="container">
          <section class="call_to_action">

               <i><h4 class="animated fadeInDown skincolored">
               “When you can measure what you are speaking about,<br>and express it in numbers, you know something about it.
               </h4></i>
               <br>
               <h4 class="animated fadeInUp"><i>
               -- Lord Kelvin
                </i></h4>
          </section>
     </div>
</div>

<div class="main">
        <section>
            <div class="container">
            <div class="row">
            <div class="col-md-4">



<h1> Contact us </h1>

<p>Have a question about any aspect of the NY Doing More with Less program?  Please be sure to let us know.</p>

<h2> Jim Bittker </h2>

<h3> Managing Director </h3>



<h4> NY Doing More with Less<sup>TM</sup> </h4>



<h4> P: 585.943.7604 </h4>

<h4> E: jim.bittker@gmail.com </h4>


<img src="assets/GBDMwL Logo.png" height="100 px" alt="NYDMwL Logo">



<h4> 37 Scarborough Park </h4>

<h4> Rochester, NY 14625 </h4>



</div>
<div class="col-md-8">


<h2> Toward a Clean Energy Economy </h2>
<p>
Human-caused climate change risks pushing our climate system toward abrupt, unpredictable, and
potentially irreversible changes with highly costly and dangerous impacts.</p><p>
By making informed choices now, leveraging innovation and market forces consistent with the Bottom
Line, organizations can lower costs and reduce risks for future generations – and ourselves.</p><p>
We can take the first steps toward a clean energy future.
<p>

<hr>

<h3>Platinum E-Firm Partners</h3>
<h4> <a href="http://www.jacomb.net/"> Jacomb Lighting </a> </h4>

<h4> <a href="http://www.taitem.com/"> Taitem Engineering </a> </h4>

<h4> <a href="http://www.larsenengineers.com/"> Larsen Engineers </a> </h4>

<h4> <a href="http://www.ipdengineering.com/"> IDP Engineering </a> </h4>


</div>
