<div class="main">
        <section>
            <div class="container">


<!-- # NY Doing More with Less ESA Deal Structure -->

<img src="assets/NYDMwL Deal Structure FULL Diagram.png" class="img-responsive center-block" alt="NYDMwL Deal Structure FULL Diagram"> 
<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>