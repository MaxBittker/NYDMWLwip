<div class="main">
        <section>
            <div class="container">


<!-- # RENEW It *Now* NY� ESA Deal Structure -->

<img src="assets/RENEW It Now ESA Deal Structure.PNG" class="img-responsive center-block" alt="RENEW It *Now* NY Deal Structure"> 
<button onclick="goBack()" type="button" class="btn btn-default" aria-label="Go Back">
  <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
 <h4>Go Back</h4>
</button>
